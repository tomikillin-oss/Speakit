
import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

// Projects store the source images
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  imageUrl: text("image_url").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Generations store the video outputs and their configuration
export const generations = pgTable("generations", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  progress: integer("progress").default(0),
  
  // Configuration used for this generation
  modelType: text("model_type").notNull(), // animatediff, svd, controlnet
  prompt: text("prompt").notNull(),
  negativePrompt: text("negative_prompt"),
  duration: integer("duration").default(5),
  aspectRatio: text("aspect_ratio").default("16:9"),
  
  // Output
  videoUrl: text("video_url"),
  logs: text("logs"), // For storing the "simulation" logs
  
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// === RELATIONS ===
export const projectsRelations = relations(projects, ({ many }) => ({
  generations: many(generations),
}));

export const generationsRelations = relations(generations, ({ one }) => ({
  project: one(projects, {
    fields: [generations.projectId],
    references: [projects.id],
  }),
}));

// === BASE SCHEMAS ===
export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true });
export const insertGenerationSchema = createInsertSchema(generations).omit({ 
  id: true, 
  createdAt: true, 
  completedAt: true,
  status: true,
  progress: true,
  videoUrl: true,
  logs: true
});

// === EXPLICIT API CONTRACT TYPES ===

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type Generation = typeof generations.$inferSelect;
export type InsertGeneration = z.infer<typeof insertGenerationSchema>;

// Status types
export type GenerationStatus = "pending" | "processing" | "completed" | "failed";

// Request types
export type CreateProjectRequest = InsertProject;
export type CreateGenerationRequest = InsertGeneration;

// Response types
export type ProjectResponse = Project & { generations?: Generation[] };
export type GenerationResponse = Generation;

export type VideoEffectType = "ken_burns" | "zoom_pulse" | "glitch_sequence" | "cyberpunk_glow";

