
import { z } from 'zod';
import { insertProjectSchema, insertGenerationSchema, projects, generations } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  projects: {
    list: {
      method: 'GET' as const,
      path: '/api/projects' as const,
      responses: {
        200: z.array(z.custom<typeof projects.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/projects' as const,
      input: insertProjectSchema,
      responses: {
        201: z.custom<typeof projects.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/projects/:id' as const,
      responses: {
        200: z.custom<typeof projects.$inferSelect & { generations: typeof generations.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
  },
  generations: {
    create: {
      method: 'POST' as const,
      path: '/api/generations' as const,
      input: insertGenerationSchema,
      responses: {
        201: z.custom<typeof generations.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/projects/:projectId/generations' as const,
      responses: {
        200: z.array(z.custom<typeof generations.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/generations/:id' as const,
      responses: {
        200: z.custom<typeof generations.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  }
};

// ============================================
// HELPER FUNCTIONS
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

// ============================================
// TYPE HELPERS
// ============================================
export type ProjectInput = z.infer<typeof api.projects.create.input>;
export type GenerationInput = z.infer<typeof api.generations.create.input>;
