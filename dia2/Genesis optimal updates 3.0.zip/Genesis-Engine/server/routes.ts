
import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Projects Endpoints
  app.get(api.projects.list.path, async (req, res) => {
    const projects = await storage.getProjects();
    res.json(projects);
  });

  app.post(api.projects.create.path, async (req, res) => {
    try {
      const input = api.projects.create.input.parse(req.body);
      const project = await storage.createProject(input);
      res.status(201).json(project);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.projects.get.path, async (req, res) => {
    const projectId = Number(req.params.id);
    const project = await storage.getProject(projectId);
    
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    const generations = await storage.getGenerations(projectId);
    res.json({ ...project, generations });
  });

  // Generations Endpoints
  app.get(api.generations.list.path, async (req, res) => {
    const projectId = Number(req.params.projectId);
    const generations = await storage.getGenerations(projectId);
    res.json(generations);
  });

  app.post(api.generations.create.path, async (req, res) => {
    try {
      const input = api.generations.create.input.parse(req.body);
      const generation = await storage.createGeneration(input);
      
      // SIMULATE PROCESSING IN BACKGROUND
      // In a real app, this would be a queue (Bull/Redis) or an external API call
      simulateGeneration(generation.id);

      res.status(201).json(generation);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.get(api.generations.get.path, async (req, res) => {
    const generation = await storage.getGeneration(Number(req.params.id));
    if (!generation) {
      return res.status(404).json({ message: 'Generation not found' });
    }
    res.json(generation);
  });

  return httpServer;
}

// Simulation Logic
function simulateGeneration(generationId: number) {
  let progress = 0;
  
  const interval = setInterval(async () => {
    progress += 10;
    
    let logMessage = "";
    if (progress < 20) logMessage = "Initializing Motion Adapter...";
    else if (progress < 40) logMessage = "Loading Stable Diffusion weights...";
    else if (progress < 60) logMessage = "Generating frames (Batch 1/3)...";
    else if (progress < 80) logMessage = "Applying temporal smoothing...";
    else logMessage = "Finalizing video encode...";

    if (progress >= 100) {
      clearInterval(interval);
      // Use a placeholder video for now
      await storage.updateGenerationStatus(
        generationId, 
        "completed", 
        100, 
        "Generation complete. Video rendered successfully.", 
        "https://cdn.pixabay.com/video/2023/10/26/186638-878455587_large.mp4" // Placeholder cyberpunk-ish video
      );
    } else {
      await storage.updateGenerationStatus(
        generationId, 
        "processing", 
        progress, 
        logMessage
      );
    }
  }, 2000); // Update every 2 seconds
}

// Seed function to populate initial data
export async function seedDatabase() {
  const existingProjects = await storage.getProjects();
  if (existingProjects.length === 0) {
    const p1 = await storage.createProject({
      name: "Cyberpunk City",
      imageUrl: "https://images.unsplash.com/photo-1605806616949-1e87b487bc2a?q=80&w=2574&auto=format&fit=crop",
      description: "Neon lights in the rain"
    });
    
    await storage.createGeneration({
      projectId: p1.id,
      modelType: "animatediff",
      prompt: "cyberpunk city, neon lights, rain, 4k, cinematic",
      status: "completed",
      progress: 100,
      videoUrl: "https://cdn.pixabay.com/video/2023/10/26/186638-878455587_large.mp4",
      logs: "Completed successfully"
    });

    const p2 = await storage.createProject({
      name: "Glitch Portrait",
      imageUrl: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?q=80&w=2550&auto=format&fit=crop",
      description: "Abstract portrait with glitch effects"
    });
  }
}
