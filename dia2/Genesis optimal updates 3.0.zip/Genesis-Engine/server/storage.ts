
import { db } from "./db";
import {
  projects,
  generations,
  type Project,
  type InsertProject,
  type Generation,
  type InsertGeneration,
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Projects
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;

  // Generations
  getGenerations(projectId: number): Promise<Generation[]>;
  getGeneration(id: number): Promise<Generation | undefined>;
  createGeneration(generation: InsertGeneration): Promise<Generation>;
  updateGenerationStatus(id: number, status: string, progress: number, logs?: string, videoUrl?: string): Promise<Generation>;
}

export class DatabaseStorage implements IStorage {
  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.createdAt));
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async getGenerations(projectId: number): Promise<Generation[]> {
    return await db
      .select()
      .from(generations)
      .where(eq(generations.projectId, projectId))
      .orderBy(desc(generations.createdAt));
  }

  async getGeneration(id: number): Promise<Generation | undefined> {
    const [generation] = await db.select().from(generations).where(eq(generations.id, id));
    return generation;
  }

  async createGeneration(generation: InsertGeneration): Promise<Generation> {
    const [newGen] = await db.insert(generations).values(generation).returning();
    return newGen;
  }

  async updateGenerationStatus(id: number, status: string, progress: number, logs?: string, videoUrl?: string): Promise<Generation> {
    const [updated] = await db
      .update(generations)
      .set({ 
        status, 
        progress, 
        logs, 
        videoUrl,
        completedAt: status === 'completed' ? new Date() : undefined 
      })
      .where(eq(generations.id, id))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
