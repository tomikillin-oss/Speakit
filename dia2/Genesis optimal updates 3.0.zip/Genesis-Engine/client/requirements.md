## Packages
framer-motion | Complex animations and page transitions for cyberpunk feel
react-dropzone | Drag and drop image uploads
clsx | Class name utility
tailwind-merge | Class name utility

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  mono: ["var(--font-mono)"],
}

API endpoints match shared/routes.ts
Images are handled via URL strings (upload simulated for MVP or handled via standard POST)
Theme is strict dark mode with neon accents
