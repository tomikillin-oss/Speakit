import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface CyberCardProps {
  children: ReactNode;
  className?: string;
  title?: string;
  subtitle?: string;
  borderColor?: "primary" | "secondary" | "accent";
}

export function CyberCard({ children, className, title, subtitle, borderColor = "primary" }: CyberCardProps) {
  const borderClasses = {
    primary: "border-primary/30 after:from-transparent after:to-primary",
    secondary: "border-secondary/30 after:from-transparent after:to-secondary",
    accent: "border-accent/30 after:from-transparent after:to-accent",
  };

  const glowClasses = {
    primary: "hover:shadow-[0_0_15px_rgba(0,255,255,0.15)]",
    secondary: "hover:shadow-[0_0_15px_rgba(255,0,255,0.15)]",
    accent: "hover:shadow-[0_0_15px_rgba(138,43,226,0.15)]",
  };

  return (
    <div className={cn(
      "relative bg-card/60 backdrop-blur-md border transition-all duration-300 group",
      borderClasses[borderColor],
      glowClasses[borderColor],
      // Clip path for corner cut
      "[clip-path:polygon(0_0,100%_0,100%_calc(100%-20px),calc(100%-20px)_100%,0_100%)]",
      className
    )}>
      {/* Corner decorative element */}
      <div className={cn(
        "absolute bottom-0 right-0 w-5 h-5 bg-gradient-to-tl opacity-50",
        borderClasses[borderColor].split(' ')[1] // re-use gradient logic roughly
      )} />

      {/* Header Line */}
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

      <div className="p-6 h-full flex flex-col">
        {(title || subtitle) && (
          <div className="mb-4">
            {title && (
              <h3 className="text-xl font-bold tracking-wider text-white uppercase font-display flex items-center gap-2">
                <span className={cn("w-1 h-4 inline-block", 
                  borderColor === "primary" ? "bg-primary" : 
                  borderColor === "secondary" ? "bg-secondary" : "bg-accent"
                )} />
                {title}
              </h3>
            )}
            {subtitle && <p className="text-sm text-muted-foreground mt-1 font-mono">{subtitle}</p>}
          </div>
        )}
        <div className="flex-1">
          {children}
        </div>
      </div>
    </div>
  );
}
