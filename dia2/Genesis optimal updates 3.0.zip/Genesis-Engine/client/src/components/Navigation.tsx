import { Link, useLocation } from "wouter";
import { LayoutDashboard, Film, Image as ImageIcon, Plus, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

export function Navigation() {
  const [location] = useLocation();

  const links = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/create", label: "New Gen", icon: Plus },
    { href: "/gallery", label: "Gallery", icon: ImageIcon },
  ];

  return (
    <nav className="fixed left-0 top-0 h-screen w-20 md:w-64 bg-black/80 backdrop-blur-xl border-r border-white/5 z-50 flex flex-col">
      <div className="p-6 flex items-center gap-3 border-b border-white/5">
        <div className="w-8 h-8 rounded-none bg-primary flex items-center justify-center shrink-0 shadow-[0_0_10px_rgba(0,255,255,0.5)]">
          <Zap className="w-5 h-5 text-black fill-black" />
        </div>
        <span className="text-xl font-bold font-display tracking-widest hidden md:block text-transparent bg-clip-text bg-gradient-to-r from-white to-white/50">
          GENESIS
        </span>
      </div>

      <div className="flex-1 py-8 flex flex-col gap-2 px-3">
        {links.map((link) => {
          const isActive = location === link.href;
          const Icon = link.icon;
          
          return (
            <Link key={link.href} href={link.href}>
              <div
                className={cn(
                  "flex items-center gap-4 px-4 py-3 rounded-sm cursor-pointer transition-all duration-200 group relative overflow-hidden",
                  isActive 
                    ? "text-primary bg-primary/10 border-r-2 border-primary" 
                    : "text-muted-foreground hover:text-white hover:bg-white/5"
                )}
              >
                {isActive && (
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent opacity-20" />
                )}
                <Icon className={cn("w-5 h-5 transition-colors", isActive ? "text-primary drop-shadow-[0_0_5px_rgba(0,255,255,0.5)]" : "group-hover:text-white")} />
                <span className="hidden md:block font-medium tracking-wide font-mono text-sm">{link.label}</span>
              </div>
            </Link>
          );
        })}
      </div>

      <div className="p-6 border-t border-white/5 hidden md:block">
        <div className="text-xs font-mono text-muted-foreground/50 text-center">
          SYSTEM V.2.0.4
          <br />
          CONNECTED
        </div>
      </div>
    </nav>
  );
}
