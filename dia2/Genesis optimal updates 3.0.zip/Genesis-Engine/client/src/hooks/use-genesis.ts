import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type ProjectInput, type GenerationInput } from "@shared/routes";

// ============================================
// PROJECTS
// ============================================

export function useProjects() {
  return useQuery({
    queryKey: [api.projects.list.path],
    queryFn: async () => {
      const res = await fetch(api.projects.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch projects");
      return api.projects.list.responses[200].parse(await res.json());
    },
  });
}

export function useProject(id: number) {
  return useQuery({
    queryKey: [api.projects.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.projects.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch project");
      return api.projects.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useCreateProject() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: ProjectInput) => {
      const res = await fetch(api.projects.create.path, {
        method: api.projects.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create project");
      return api.projects.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.projects.list.path] });
    },
  });
}

// ============================================
// GENERATIONS
// ============================================

export function useProjectGenerations(projectId: number) {
  return useQuery({
    queryKey: [api.generations.list.path, projectId],
    queryFn: async () => {
      const url = buildUrl(api.generations.list.path, { projectId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch generations");
      return api.generations.list.responses[200].parse(await res.json());
    },
    enabled: !!projectId,
    // Poll every 3 seconds if we have active generations
    refetchInterval: (query) => {
      const hasActive = query.state.data?.some(
        (g) => g.status === "pending" || g.status === "processing"
      );
      return hasActive ? 3000 : false;
    },
  });
}

export function useCreateGeneration() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: GenerationInput) => {
      const res = await fetch(api.generations.create.path, {
        method: api.generations.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to start generation");
      return api.generations.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      // Invalidate project generations list
      const listUrl = buildUrl(api.generations.list.path, { projectId: variables.projectId });
      queryClient.invalidateQueries({ queryKey: [api.generations.list.path, variables.projectId] });
      // Also invalidate single project view as it might contain generation list
      queryClient.invalidateQueries({ queryKey: [api.projects.get.path, variables.projectId] });
    },
  });
}

export function useGeneration(id: number) {
  return useQuery({
    queryKey: [api.generations.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.generations.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch generation");
      return api.generations.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
    refetchInterval: (query) => {
      const status = query.state.data?.status;
      return status === "pending" || status === "processing" ? 1000 : false;
    },
  });
}
