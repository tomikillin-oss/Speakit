import { useProjects } from "@/hooks/use-genesis";
import { CyberCard } from "@/components/CyberCard";
import { Loader2, Play, Download } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function Gallery() {
  const { data: projects, isLoading } = useProjects();
  // In a real app we'd have a separate endpoint for "all completed generations"
  // For now, we'll just show projects as a placeholder for the gallery

  return (
    <div className="p-6 md:p-12 max-w-7xl mx-auto min-h-screen">
       <div className="mb-12 text-center">
         <h1 className="text-5xl md:text-7xl font-bold font-display text-transparent bg-clip-text bg-gradient-to-b from-white to-white/20 mb-4">
           ARCHIVES
         </h1>
         <p className="text-primary font-mono tracking-widest uppercase text-sm">
           Output Repository // Access Level 5
         </p>
       </div>

       {isLoading ? (
         <div className="flex justify-center">
           <Loader2 className="w-8 h-8 text-primary animate-spin" />
         </div>
       ) : (
         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects?.map((project, i) => (
              <motion.div 
                key={project.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <Link href={`/project/${project.id}`}>
                  <div className="group cursor-pointer">
                    <div className="relative aspect-[9/16] md:aspect-video rounded-sm overflow-hidden border border-white/10 group-hover:border-primary/50 transition-colors bg-black">
                      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/80 z-10" />
                      
                      {/* Image Source */}
                      <img 
                        src={project.imageUrl} 
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60 group-hover:opacity-100" 
                      />

                      {/* Hover Overlay */}
                      <div className="absolute inset-0 z-20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 backdrop-blur-[2px]">
                        <div className="w-16 h-16 rounded-full border-2 border-primary flex items-center justify-center bg-black/50">
                          <Play className="w-6 h-6 text-primary ml-1" />
                        </div>
                      </div>

                      {/* Info */}
                      <div className="absolute bottom-0 left-0 right-0 p-6 z-20 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                        <h3 className="text-xl font-bold text-white mb-1 font-display">{project.name}</h3>
                        <p className="text-xs font-mono text-muted-foreground">
                          {new Date(project.createdAt || "").toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
         </div>
       )}
    </div>
  );
}
