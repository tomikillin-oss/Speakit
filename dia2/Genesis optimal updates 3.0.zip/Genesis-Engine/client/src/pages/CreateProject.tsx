import { useState, useCallback } from "react";
import { useLocation } from "wouter";
import { useCreateProject } from "@/hooks/use-genesis";
import { useDropzone } from "react-dropzone";
import { CyberCard } from "@/components/CyberCard";
import { Upload, X, Check, Loader2, ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "wouter";

export default function CreateProject() {
  const [, setLocation] = useLocation();
  const { mutate, isPending } = useCreateProject();
  
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [dragActive, setDragActive] = useState(false);

  // Mock upload since we don't have a real file server in this demo
  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      // Create a fake URL for preview
      const url = URL.createObjectURL(file);
      setImageUrl(url);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: { 'image/*': [] },
    maxFiles: 1
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !imageUrl) return;

    mutate({
      name,
      description,
      imageUrl, // In a real app, this would be the URL returned from S3/upload
    }, {
      onSuccess: (data) => {
        setLocation(`/project/${data.id}`);
      }
    });
  };

  return (
    <div className="p-6 md:p-12 max-w-4xl mx-auto min-h-screen flex flex-col">
      <div className="mb-8">
        <Link href="/">
          <button className="text-muted-foreground hover:text-white flex items-center gap-2 mb-4 text-sm font-mono transition-colors">
            <ArrowLeft className="w-4 h-4" /> BACK TO COMMAND
          </button>
        </Link>
        <h1 className="text-3xl md:text-4xl font-bold text-white mb-2 neon-text">
          INITIATE NEW PROJECT
        </h1>
        <p className="text-muted-foreground font-mono">
          Configure initial parameters for the simulation environment.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="flex-1 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column: Image Upload */}
          <div className="space-y-4">
            <label className="text-sm font-bold text-primary font-mono tracking-wider uppercase">
              Source Asset
            </label>
            
            <div 
              {...getRootProps()}
              className={cn(
                "aspect-square rounded-sm border-2 border-dashed transition-all duration-300 flex flex-col items-center justify-center p-6 cursor-pointer relative overflow-hidden group",
                isDragActive 
                  ? "border-primary bg-primary/10" 
                  : imageUrl 
                    ? "border-primary/50 bg-black" 
                    : "border-white/10 hover:border-white/30 hover:bg-white/5"
              )}
            >
              <input {...getInputProps()} />
              
              {imageUrl ? (
                <>
                  <img 
                    src={imageUrl} 
                    alt="Preview" 
                    className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity" 
                  />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10">
                    <div className="bg-black/80 px-4 py-2 border border-primary text-primary text-xs font-mono uppercase">
                      Replace Asset
                    </div>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 bg-black/80 p-2 border-t border-white/10 flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    <span className="text-[10px] font-mono text-green-500">ASSET LOADED</span>
                  </div>
                </>
              ) : (
                <div className="text-center space-y-4">
                  <div className={cn(
                    "w-16 h-16 rounded-full flex items-center justify-center mx-auto transition-colors",
                    isDragActive ? "bg-primary text-black" : "bg-white/5 text-muted-foreground group-hover:text-white"
                  )}>
                    <Upload className="w-8 h-8" />
                  </div>
                  <div>
                    <p className="text-white font-bold text-sm uppercase mb-1">Upload Source Image</p>
                    <p className="text-xs text-muted-foreground font-mono">DRAG & DROP OR CLICK TO BROWSE</p>
                  </div>
                </div>
              )}
              
              {/* Corner accents */}
              <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-primary/50" />
              <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-primary/50" />
              <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-primary/50" />
              <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-primary/50" />
            </div>
          </div>

          {/* Right Column: Form Fields */}
          <div className="space-y-6">
            <div className="space-y-2">
              <label htmlFor="name" className="text-sm font-bold text-white font-mono tracking-wider uppercase">
                Project Codename
              </label>
              <input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="ex. CYBER_PUNK_01"
                className="w-full px-4 py-3 cyber-input"
                autoFocus
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="description" className="text-sm font-bold text-muted-foreground font-mono tracking-wider uppercase">
                Mission Description
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Optional operational details..."
                rows={4}
                className="w-full px-4 py-3 cyber-input resize-none"
              />
            </div>

            <CyberCard borderColor="accent" className="mt-8 bg-accent/5 border-accent/20">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-accent/20 rounded-sm">
                  <Upload className="w-4 h-4 text-accent" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white mb-1">READY FOR UPLOAD</h4>
                  <p className="text-xs text-muted-foreground">
                    Ensure source assets comply with protocol v2.4. Max file size 25MB. Supported formats: PNG, JPG, WEBP.
                  </p>
                </div>
              </div>
            </CyberCard>

            <div className="pt-4 flex items-center justify-end gap-4">
              <Link href="/">
                <button type="button" className="px-6 py-2 text-sm font-mono text-muted-foreground hover:text-white transition-colors">
                  ABORT
                </button>
              </Link>
              <button
                type="submit"
                disabled={!name || !imageUrl || isPending}
                className="cyber-button min-w-[140px] flex items-center justify-center gap-2"
              >
                {isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    PROCESSING
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    INITIALIZE
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
