import { useState } from "react";
import { useParams, useRoute } from "wouter";
import { useProject, useCreateGeneration, useProjectGenerations } from "@/hooks/use-genesis";
import { CyberCard } from "@/components/CyberCard";
import { 
  Play, Pause, Download, Settings, RefreshCw, 
  Terminal, Sliders, Film, Loader2, AlertCircle 
} from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

export default function ProjectDetails() {
  const params = useParams();
  const id = Number(params.id);
  const { data: project, isLoading: isProjectLoading } = useProject(id);
  const { data: generations, isLoading: isGensLoading } = useProjectGenerations(id);
  const { mutate: createGen, isPending: isCreating } = useCreateGeneration();

  const [prompt, setPrompt] = useState("cyberpunk city with neon lights, rain, reflections, detailed, 8k");
  const [modelType, setModelType] = useState("animatediff");
  const [activeGenId, setActiveGenId] = useState<number | null>(null);

  // Auto-select first generation if available and none selected
  if (!activeGenId && generations && generations.length > 0) {
    setActiveGenId(generations[0].id);
  }

  const activeGeneration = generations?.find(g => g.id === activeGenId);

  const handleGenerate = () => {
    if (!project) return;
    createGen({
      projectId: project.id,
      prompt,
      modelType,
      status: "pending",
      progress: 0
    });
  };

  if (isProjectLoading) {
    return (
      <div className="h-screen flex items-center justify-center flex-col gap-4">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
        <p className="text-primary font-mono tracking-widest animate-pulse">LOADING PROJECT DATA...</p>
      </div>
    );
  }

  if (!project) return <div>Project not found</div>;

  return (
    <div className="h-screen flex flex-col md:flex-row overflow-hidden bg-background">
      {/* LEFT PANEL - Editor/Config */}
      <div className="w-full md:w-[400px] lg:w-[450px] flex flex-col border-r border-white/10 bg-black/40 backdrop-blur-sm z-10 h-full overflow-y-auto custom-scrollbar">
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2 py-0.5 bg-primary/20 text-primary text-[10px] font-mono border border-primary/50">
              PRJ-{project.id}
            </span>
            <h2 className="text-xl font-bold text-white truncate">{project.name}</h2>
          </div>
          <p className="text-xs text-muted-foreground font-mono line-clamp-2">
            {project.description || "No description provided."}
          </p>
        </div>

        <div className="p-6 space-y-8 flex-1">
          {/* Source Image */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-bold text-muted-foreground font-mono">
              <span className="flex items-center gap-2"><ImageIcon className="w-3 h-3" /> SOURCE ASSET</span>
              <span className="text-green-500">ACTIVE</span>
            </div>
            <div className="aspect-video w-full rounded-sm overflow-hidden border border-white/10 relative group">
              <img src={project.imageUrl} className="w-full h-full object-cover opacity-70 group-hover:opacity-100 transition-opacity" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-50" />
            </div>
          </div>

          <div className="w-full h-[1px] bg-white/10" />

          {/* Configuration Form */}
          <div className="space-y-6">
            <div className="flex items-center gap-2 text-primary font-bold text-sm tracking-wider">
              <Settings className="w-4 h-4" /> CONFIGURATION
            </div>

            <div className="space-y-3">
              <label className="text-xs font-mono text-muted-foreground uppercase">Model Architecture</label>
              <div className="grid grid-cols-2 gap-2">
                {['animatediff', 'svd_xt', 'controlnet'].map((model) => (
                  <button
                    key={model}
                    onClick={() => setModelType(model)}
                    className={cn(
                      "px-3 py-2 text-xs font-mono border transition-all text-left uppercase",
                      modelType === model 
                        ? "bg-primary/20 border-primary text-primary" 
                        : "bg-transparent border-white/10 text-muted-foreground hover:border-white/30"
                    )}
                  >
                    {model}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-mono text-muted-foreground uppercase">Prompt Directive</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={4}
                className="w-full bg-black/50 border border-white/10 p-3 text-sm text-white font-mono focus:border-primary outline-none transition-colors"
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={isCreating}
              className="w-full cyber-button py-4 text-base flex items-center justify-center gap-2 mt-4"
            >
              {isCreating ? <Loader2 className="animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
              {isCreating ? "INITIALIZING..." : "EXECUTE GENERATION"}
            </button>
          </div>
        </div>
      </div>

      {/* RIGHT PANEL - Preview & History */}
      <div className="flex-1 flex flex-col h-full bg-grid-white/[0.02] relative overflow-hidden">
        {/* Main Preview Area */}
        <div className="flex-1 p-6 md:p-12 flex flex-col items-center justify-center relative">
          {/* Background Grid Effect */}
          <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />

          {activeGeneration ? (
            <div className="w-full max-w-4xl space-y-6 z-10">
              <CyberCard className="w-full overflow-hidden p-0 bg-black/40 border-primary/20">
                <div className="aspect-video w-full bg-black relative flex items-center justify-center">
                  {activeGeneration.status === "completed" && activeGeneration.videoUrl ? (
                    <video 
                      src={activeGeneration.videoUrl} 
                      controls 
                      autoPlay 
                      loop 
                      className="w-full h-full object-contain"
                    />
                  ) : activeGeneration.status === "failed" ? (
                    <div className="flex flex-col items-center text-destructive gap-3">
                      <AlertCircle className="w-12 h-12" />
                      <p className="font-mono text-lg">GENERATION FAILED</p>
                    </div>
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center gap-6 relative">
                      {/* Loading Animation */}
                      <div className="absolute inset-0 bg-primary/5 animate-pulse" />
                      <div className="w-24 h-24 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
                      <div className="text-center z-10 space-y-2">
                        <p className="text-2xl font-bold text-white font-display tracking-widest animate-pulse">
                          {activeGeneration.status === "pending" ? "QUEUED" : "PROCESSING"}
                        </p>
                        <p className="text-primary font-mono">
                          {activeGeneration.progress || 0}% COMPLETE
                        </p>
                      </div>
                    </div>
                  )}
                </div>
                
                {/* Generation Meta Footer */}
                <div className="p-4 border-t border-white/10 bg-black/60 flex items-center justify-between">
                  <div className="flex items-center gap-4 text-xs font-mono text-muted-foreground">
                    <span>ID: {activeGeneration.id}</span>
                    <span className="w-1 h-4 bg-white/10" />
                    <span className="uppercase">{activeGeneration.modelType}</span>
                    <span className="w-1 h-4 bg-white/10" />
                    <span>{new Date(activeGeneration.createdAt || Date.now()).toLocaleTimeString()}</span>
                  </div>
                  {activeGeneration.status === "completed" && (
                     <button className="flex items-center gap-2 text-xs font-bold text-primary hover:text-white transition-colors">
                       <Download className="w-4 h-4" /> DOWNLOAD
                     </button>
                  )}
                </div>
              </CyberCard>
              
              {/* Logs Console */}
              <div className="h-48 bg-black/80 border border-white/10 rounded-sm p-4 font-mono text-xs overflow-y-auto custom-scrollbar">
                <div className="text-muted-foreground mb-2 border-b border-white/10 pb-2 flex items-center gap-2">
                  <Terminal className="w-3 h-3" /> SYSTEM LOGS
                </div>
                <div className="space-y-1">
                  <p className="text-green-500">[{new Date().toLocaleTimeString()}] System connected.</p>
                  <p className="text-blue-400">[{new Date().toLocaleTimeString()}] Loaded project configuration.</p>
                  {activeGeneration.logs?.split('\n').map((log, i) => (
                    <p key={i} className="text-muted-foreground">{log}</p>
                  ))}
                  {activeGeneration.status === 'processing' && (
                    <p className="text-primary animate-pulse">... processing frames ...</p>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center space-y-4 opacity-50">
              <Film className="w-16 h-16 mx-auto text-muted-foreground" />
              <h3 className="text-xl font-display text-white">NO GENERATION SELECTED</h3>
              <p className="text-muted-foreground font-mono max-w-sm mx-auto">
                Select a previous run from the history panel below or start a new generation.
              </p>
            </div>
          )}
        </div>

        {/* Bottom History Strip */}
        <div className="h-40 border-t border-white/10 bg-black/40 backdrop-blur-md flex flex-col">
          <div className="px-6 py-2 border-b border-white/5 flex items-center justify-between">
            <h3 className="text-xs font-bold text-muted-foreground font-mono uppercase">History Buffer</h3>
            <span className="text-[10px] text-muted-foreground bg-white/5 px-2 py-0.5 rounded-full">
              {generations?.length || 0} ITEMS
            </span>
          </div>
          <div className="flex-1 p-4 overflow-x-auto custom-scrollbar flex items-center gap-4">
            {generations?.map((gen) => (
              <button
                key={gen.id}
                onClick={() => setActiveGenId(gen.id)}
                className={cn(
                  "relative h-24 aspect-video shrink-0 border transition-all duration-300 group overflow-hidden",
                  activeGenId === gen.id 
                    ? "border-primary shadow-[0_0_10px_rgba(0,255,255,0.3)] scale-105 z-10" 
                    : "border-white/10 hover:border-white/40 hover:scale-105 opacity-60 hover:opacity-100"
                )}
              >
                {gen.videoUrl ? (
                   <video src={gen.videoUrl} className="w-full h-full object-cover" muted />
                ) : (
                   <div className="w-full h-full bg-white/5 flex items-center justify-center">
                     <Loader2 className={cn("w-6 h-6 text-muted-foreground", gen.status === 'processing' && "animate-spin")} />
                   </div>
                )}
                
                {/* Status Indicator */}
                <div className={cn(
                  "absolute top-1 right-1 w-2 h-2 rounded-full",
                  gen.status === 'completed' ? "bg-green-500" :
                  gen.status === 'failed' ? "bg-red-500" : "bg-primary animate-pulse"
                )} />
                
                {activeGenId === gen.id && (
                  <div className="absolute inset-0 border-2 border-primary pointer-events-none" />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function ImageIcon({className}: {className?: string}) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" height="24" viewBox="0 0 24 24" 
      fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" 
      className={className}
    >
      <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
      <circle cx="9" cy="9" r="2" />
      <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
    </svg>
  );
}
