import { useProjects } from "@/hooks/use-genesis";
import { CyberCard } from "@/components/CyberCard";
import { Link } from "wouter";
import { Plus, ArrowRight, Activity, Clock, Layers, Zap } from "lucide-react";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { data: projects, isLoading } = useProjects();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full w-full">
        <div className="text-primary font-mono animate-pulse">INITIALIZING DASHBOARD...</div>
      </div>
    );
  }

  // Calculate stats
  const totalProjects = projects?.length || 0;
  // Mock data for display purposes
  const systemStatus = "OPTIMAL";
  const gpuLoad = "34%";

  return (
    <div className="p-6 md:p-12 max-w-7xl mx-auto space-y-12">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 border-b border-white/10 pb-8">
        <div>
          <h1 className="text-4xl md:text-5xl font-bold mb-2 text-white neon-text">
            OPERATIONS CENTER
          </h1>
          <p className="text-muted-foreground font-mono">
            Welcome back, Operator. System ready for synthesis.
          </p>
        </div>
        
        <Link href="/create">
          <button className="cyber-button flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Initialize Project
          </button>
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <CyberCard borderColor="primary" className="h-32">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-primary font-mono mb-1">ACTIVE PROJECTS</p>
              <h2 className="text-4xl font-bold font-display">{totalProjects}</h2>
            </div>
            <Layers className="text-primary/50 w-8 h-8" />
          </div>
        </CyberCard>
        
        <CyberCard borderColor="secondary" className="h-32">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-secondary font-mono mb-1">SYSTEM STATUS</p>
              <h2 className="text-4xl font-bold font-display">{systemStatus}</h2>
            </div>
            <Activity className="text-secondary/50 w-8 h-8" />
          </div>
        </CyberCard>

        <CyberCard borderColor="accent" className="h-32">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs text-accent font-mono mb-1">GPU LOAD</p>
              <h2 className="text-4xl font-bold font-display">{gpuLoad}</h2>
            </div>
            <Zap className="text-accent/50 w-8 h-8" />
          </div>
        </CyberCard>
      </div>

      {/* Projects Grid */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold flex items-center gap-3">
            <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            RECENT PROJECTS
          </h2>
          <span className="text-xs font-mono text-muted-foreground">SHOWING ALL ENTRIES</span>
        </div>

        {projects?.length === 0 ? (
          <div className="border border-dashed border-white/10 rounded-lg p-12 flex flex-col items-center justify-center text-center bg-white/5">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4">
              <Layers className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">NO ACTIVE PROJECTS</h3>
            <p className="text-muted-foreground max-w-md mb-6">
              The database is empty. Initialize a new project to begin the generation sequence.
            </p>
            <Link href="/create">
              <button className="cyber-button-secondary">Create New Project</button>
            </Link>
          </div>
        ) : (
          <motion.div 
            variants={container}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {projects?.map((project) => (
              <motion.div key={project.id} variants={item}>
                <Link href={`/project/${project.id}`}>
                  <div className="group cursor-pointer">
                    <CyberCard className="h-full hover:-translate-y-1 transition-transform duration-300">
                      <div className="aspect-video w-full overflow-hidden rounded-sm bg-black relative mb-4 border border-white/10 group-hover:border-primary/50 transition-colors">
                        {/* Image overlay gradient */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10" />
                        
                        <img 
                          src={project.imageUrl} 
                          alt={project.name}
                          className="w-full h-full object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"
                        />
                        
                        <div className="absolute bottom-3 left-3 z-20">
                          <span className="text-xs font-mono bg-black/50 backdrop-blur px-2 py-1 border border-white/20 text-white">
                            ID: {project.id.toString().padStart(4, '0')}
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-bold text-white group-hover:text-primary transition-colors truncate pr-4">
                            {project.name}
                          </h3>
                          <p className="text-xs text-muted-foreground font-mono mt-1 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(project.createdAt || Date.now()).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="w-8 h-8 rounded-sm bg-white/5 flex items-center justify-center group-hover:bg-primary group-hover:text-black transition-colors">
                          <ArrowRight className="w-4 h-4" />
                        </div>
                      </div>
                    </CyberCard>
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </div>
  );
}
