import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import express from "express";
import ffmpeg from "fluent-ffmpeg";
import { v4 as uuidv4 } from "uuid";
import { jobTypes } from "@shared/schema";
import { generateImageBuffer } from "./replit_integrations/image";

const uploadDir = path.join(process.cwd(), "uploads");
const outputDir = path.join(process.cwd(), "outputs");
[uploadDir, outputDir].forEach(dir => { if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true }); });

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      cb(null, `${uuidv4()}${ext}`);
    }
  })
});

const KALEVALA_STYLES: Record<string, any> = {
  mythic: {
    positive: "ancient finnish mythology, kalevala, rune singer, mystical atmosphere, epic landscape, golden age, sampo, ilmarinen, väinämöinen, ethereal lighting",
    negative: "modern, urban, technology, cars, buildings"
  },
  cyber_kalevala: {
    positive: "kalevala mythology cyberpunk fusion, neon runes, digital shaman, holographic kantele, data streams, bioluminescent forest, retrofuturistic",
    negative: "medieval, historical, boring, plain"
  },
  shamanic: {
    positive: "finnish shaman, noaidi, drum journey, spirit world, northern lights, trance state, ancestral wisdom",
    negative: "western, christian, modern clothes"
  }
};

const CHARACTER_PROMPTS: Record<string, string> = {
  vaino: "old wise man, white beard, blue robes, magical aura",
  agent7: "cybernetic agent, orange accents, tactical gear, glowing eyes",
  shamaani: "mystical shaman, purple robes, ethereal, transcendent"
};

const generateDNA = () => ({
  visual: { saturation: Math.random() * 1.5 + 0.5, contrast: Math.random() * 0.4 + 0.8, grain: Math.random() * 0.3 },
  temporal: { speed: Math.random() * 1.5 + 0.5, transition_speed: Math.random() * 0.9 + 0.1, loop_seamless: Math.random() * 0.3 + 0.7 },
  narrative: { archetype: ["hero", "mystery", "transformation", "journey"][Math.floor(Math.random() * 4)], conflict: Math.random() * 0.5 + 0.3 }
});

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  app.use('/uploads', express.static(uploadDir));
  app.use('/outputs', express.static(outputDir));

  app.post(api.upload.create.path, upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ message: "No file uploaded" });
    res.json({ url: `/uploads/${req.file.filename}`, filename: req.file.filename, mimetype: req.file.mimetype });
  });

  app.post(api.ai.generateImage.path, async (req, res) => {
    try {
      const { prompt, style, character } = api.ai.generateImage.input.parse(req.body);
      const styleData = KALEVALA_STYLES[style] || KALEVALA_STYLES.cyber_kalevala;
      let fullPrompt = `${styleData.positive}, ${prompt}`;
      if (character) fullPrompt += `, ${CHARACTER_PROMPTS[character] || ""}`;

      const dna = generateDNA();
      const job = await storage.createJob({
        type: jobTypes.AI_IMAGE,
        prompt: fullPrompt,
        style,
        dna,
        inputUrl: ""
      });

      (async () => {
        try {
          await storage.updateJob(job.id, { status: "processing" });
          const imageBuffer = await generateImageBuffer(fullPrompt);
          const filename = `${uuidv4()}.png`;
          const outputPath = path.join(outputDir, filename);
          fs.writeFileSync(outputPath, imageBuffer);
          await storage.updateJob(job.id, { status: "completed", outputUrl: `/outputs/${filename}` });
        } catch (err) {
          await storage.updateJob(job.id, { status: "failed", error: String(err) });
        }
      })();

      res.status(201).json(job);
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.post(api.jobs.create.path, async (req, res) => {
    try {
      const input = api.jobs.create.input.parse(req.body);
      const dna = generateDNA();
      const job = await storage.createJob({ ...input, dna });
      
      processJob(job.id, { ...input, dna }).catch(err => {
        console.error(`Job ${job.id} error:`, err);
        storage.updateJob(job.id, { status: "failed", error: String(err) });
      });
      
      res.status(201).json(job);
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.get(api.jobs.get.path, async (req, res) => {
    const job = await storage.getJob(Number(req.params.id));
    if (!job) return res.status(404).json({ message: "Not found" });
    res.json(job);
  });

  app.get(api.jobs.list.path, async (req, res) => res.json(await storage.listJobs()));

  return httpServer;
}

async function processJob(jobId: number, input: any) {
  await storage.updateJob(jobId, { status: "processing" });
  const inputPath = path.join(process.cwd(), input.inputUrl.replace(/^\//, ''));
  const outputFilename = `${uuidv4()}.mp4`;
  const outputPath = path.join(outputDir, outputFilename);

  try {
    if (input.type === jobTypes.VIIKUOJA_ANIM) {
      await new Promise((resolve, reject) => {
        ffmpeg(inputPath)
          .inputOptions(['-loop 1'])
          .videoFilters([`zoompan=z='min(zoom+0.0015,1.5)':d=150:s=1280x720`])
          .outputOptions(['-t 5', '-pix_fmt yuv420p', '-crf 18'])
          .on('end', resolve).on('error', reject).save(outputPath);
      });
    } else {
      fs.copyFileSync(inputPath, outputPath);
    }
    await storage.updateJob(jobId, { status: "completed", outputUrl: `/outputs/${outputFilename}` });
  } catch (err) {
    await storage.updateJob(jobId, { status: "failed", error: String(err) });
  }
}
