import { Job } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { Loader2, CheckCircle2, XCircle, Clock, Video, Image as ImageIcon, Wand2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface JobCardProps {
  job: Job;
  onClick: () => void;
}

export function JobCard({ job, onClick }: JobCardProps) {
  const getStatusIcon = () => {
    switch (job.status) {
      case "pending":
      case "processing":
        return <Loader2 className="w-5 h-5 text-primary animate-spin" />;
      case "completed":
        return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case "failed":
        return <XCircle className="w-5 h-5 text-destructive" />;
      default:
        return <Clock className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getTypeIcon = () => {
    switch (job.type) {
      case "speed":
        return <Video className="w-4 h-4" />;
      case "anim":
        return <ImageIcon className="w-4 h-4" />;
      case "watermark":
        return <Wand2 className="w-4 h-4" />;
      default:
        return <Video className="w-4 h-4" />;
    }
  };

  const getStatusColor = () => {
    switch (job.status) {
      case "completed": return "border-green-500/20 hover:border-green-500/40";
      case "failed": return "border-destructive/20 hover:border-destructive/40";
      case "processing": return "border-primary/20 hover:border-primary/40";
      default: return "border-border hover:border-primary/20";
    }
  };

  return (
    <Card 
      className={`
        p-4 cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 
        bg-card/50 backdrop-blur-sm border ${getStatusColor()} group
      `}
      onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-secondary/50 text-primary group-hover:text-white group-hover:bg-primary/20 transition-colors">
            {getTypeIcon()}
          </div>
          <div>
            <h3 className="font-semibold text-foreground truncate max-w-[150px] sm:max-w-[200px]">
              {job.originalFilename || "Untitled Job"}
            </h3>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
              {job.createdAt && formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {getStatusIcon()}
        </div>
      </div>
      
      {job.error && (
        <div className="mt-3 p-2 rounded bg-destructive/10 border border-destructive/20 text-xs text-destructive">
          {job.error}
        </div>
      )}
      
      <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
        <span className="bg-secondary px-2 py-1 rounded-full uppercase font-bold tracking-wider text-[10px]">
          {job.type}
        </span>
        <span className="capitalize">{job.status}</span>
      </div>
    </Card>
  );
}
