import { useCallback, useState } from "react";
import { UploadCloud, File as FileIcon, Loader2, X } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface FileUploadProps {
  accept: Record<string, string[]>;
  onUpload: (file: File) => Promise<void>;
  isUploading: boolean;
  value?: string | null;
  onClear: () => void;
  label?: string;
}

export function FileUpload({ accept, onUpload, isUploading, value, onClear, label = "Drop files here" }: FileUploadProps) {
  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      await onUpload(acceptedFiles[0]);
    }
  }, [onUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept,
    maxFiles: 1,
    disabled: isUploading || !!value
  });

  if (value) {
    return (
      <div className="relative group">
        <div className="rounded-xl border border-primary/20 bg-primary/5 p-8 flex flex-col items-center justify-center gap-4 text-center overflow-hidden">
          {accept['image/*'] ? (
            <img src={value} alt="Preview" className="h-48 object-contain rounded-lg shadow-md" />
          ) : (
            <video src={value} controls className="h-48 rounded-lg shadow-md bg-black" />
          )}
          <p className="text-sm text-muted-foreground break-all max-w-full px-4">
             File ready for processing
          </p>
        </div>
        <Button
          size="icon"
          variant="destructive"
          className="absolute top-2 right-2 rounded-full w-8 h-8 opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
          onClick={(e) => {
            e.stopPropagation();
            onClear();
          }}
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
    );
  }

  return (
    <div
      {...getRootProps()}
      className={cn(
        "relative rounded-xl border-2 border-dashed transition-all duration-300 p-12 cursor-pointer flex flex-col items-center justify-center gap-4 text-center group",
        isDragActive 
          ? "border-primary bg-primary/10 scale-[1.02]" 
          : "border-white/10 hover:border-primary/50 hover:bg-secondary/50 bg-secondary/20",
        isUploading && "opacity-50 pointer-events-none"
      )}
    >
      <input {...getInputProps()} />
      
      <div className="relative">
        <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mb-2 group-hover:scale-110 transition-transform duration-300 border border-white/5">
          {isUploading ? (
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          ) : (
            <UploadCloud className="w-8 h-8 text-primary group-hover:text-primary-foreground transition-colors" />
          )}
        </div>
        {isUploading && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-full h-full rounded-full border-2 border-primary border-t-transparent animate-spin" />
          </div>
        )}
      </div>

      <div className="space-y-1">
        <p className="text-lg font-medium">
          {isUploading ? "Uploading..." : label}
        </p>
        <p className="text-sm text-muted-foreground">
          {isUploading ? "Please wait" : "Drag & drop or click to browse"}
        </p>
      </div>
    </div>
  );
}
