import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Dna, Zap, Film, Sparkles, Activity, Library, Loader2, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Dashboard() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("forge");
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("cyber_kalevala");
  const [character, setCharacter] = useState("agent7");
  const [dna, setDna] = useState<any>(null);

  const { data: jobs, isLoading: jobsLoading } = useQuery<any[]>({
    queryKey: ["/api/jobs"],
  });

  const forgeMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch("/api/ai/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Forge failed");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Synthesis Started", description: "The DNA Forge is active." });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
    },
  });

  const jobMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await fetch("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Synthesis failed");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Evolution Started", description: "DNA mutation in progress." });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
    },
  });

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 p-8 font-sans selection:bg-emerald-500/30">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-zinc-800 pb-6">
          <div>
            <h1 className="text-4xl font-black tracking-tighter bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
              GENESIS 2.0
            </h1>
            <p className="text-zinc-500 text-sm font-mono uppercase tracking-widest mt-1">VII KUOJA EDITION</p>
          </div>
          <div className="flex gap-4">
            <div className="text-right">
              <p className="text-xs text-zinc-500 uppercase">Frames Generated</p>
              <p className="text-xl font-mono text-emerald-400">12,402</p>
            </div>
            <div className="text-right border-l border-zinc-800 pl-4">
              <p className="text-xs text-zinc-500 uppercase">DNA Generations</p>
              <p className="text-xl font-mono text-cyan-400">842</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Controls */}
          <div className="lg:col-span-2 space-y-8">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="bg-zinc-900 border border-zinc-800 p-1">
                <TabsTrigger value="forge" className="data-[state=active]:bg-zinc-800">
                  <Sparkles className="w-4 h-4 mr-2" />
                  AI Forge
                </TabsTrigger>
                <TabsTrigger value="evolve" className="data-[state=active]:bg-zinc-800">
                  <Zap className="w-4 h-4 mr-2" />
                  Evolution
                </TabsTrigger>
                <TabsTrigger value="archive" className="data-[state=active]:bg-zinc-800">
                  <Library className="w-4 h-4 mr-2" />
                  Archive
                </TabsTrigger>
              </TabsList>

              <TabsContent value="forge" className="mt-6">
                <Card className="bg-zinc-900 border-zinc-800 shadow-2xl overflow-hidden relative">
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                    <Sparkles className="w-32 h-32 text-emerald-500" />
                  </div>
                  <CardHeader>
                    <CardTitle className="text-emerald-400">AI Image Creation</CardTitle>
                    <CardDescription>Synthesize new mythic imagery from the void.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <Label>Visionary Prompt</Label>
                      <Input 
                        placeholder="Describe your mythic vision..." 
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="bg-zinc-950 border-zinc-800 focus:ring-emerald-500"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Style Protocol</Label>
                        <Select value={style} onValueChange={setStyle}>
                          <SelectTrigger className="bg-zinc-950 border-zinc-800">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-zinc-900 border-zinc-800">
                            <SelectItem value="mythic">Mythic Kalevala</SelectItem>
                            <SelectItem value="cyber_kalevala">Cyber Fusion</SelectItem>
                            <SelectItem value="shamanic">Shamanic Path</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Entity Avatar</Label>
                        <Select value={character} onValueChange={setCharacter}>
                          <SelectTrigger className="bg-zinc-950 border-zinc-800">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-zinc-900 border-zinc-800">
                            <SelectItem value="vaino">Wise Väinö</SelectItem>
                            <SelectItem value="agent7">Agent VII</SelectItem>
                            <SelectItem value="shamaani">The Shaman</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <Button 
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold tracking-tighter"
                      onClick={() => forgeMutation.mutate({ prompt, style, character })}
                      disabled={forgeMutation.isPending || !prompt}
                    >
                      {forgeMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                      FORGE GENESIS IMAGE
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="evolve" className="mt-6">
                 {/* Similar structure for Evolution */}
                 <Card className="bg-zinc-900 border-zinc-800">
                   <CardHeader>
                     <CardTitle className="text-cyan-400">Media Evolution</CardTitle>
                     <CardDescription>Mutate images into cinematic temporal sequences.</CardDescription>
                   </CardHeader>
                   <CardContent className="flex flex-col items-center justify-center p-12 border-2 border-dashed border-zinc-800 rounded-lg bg-zinc-950/50">
                     <Film className="w-12 h-12 text-zinc-700 mb-4" />
                     <p className="text-zinc-500 text-sm">Upload media to begin DNA Synthesis</p>
                     <Button variant="outline" className="mt-4 border-zinc-700">Select Source</Button>
                   </CardContent>
                 </Card>
              </TabsContent>

              <TabsContent value="archive" className="mt-6">
                <div className="grid grid-cols-2 gap-4">
                  {jobs?.map((job) => (
                    <Card key={job.id} className="bg-zinc-900 border-zinc-800 overflow-hidden group">
                      {job.outputUrl ? (
                        <div className="aspect-square relative">
                          <img src={job.outputUrl} className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 to-transparent opacity-60" />
                          <div className="absolute bottom-0 left-0 p-3">
                            <p className="text-xs font-mono text-emerald-400">{job.type}</p>
                            <p className="text-[10px] text-zinc-400">{new Date(job.createdAt).toLocaleDateString()}</p>
                          </div>
                        </div>
                      ) : (
                        <div className="aspect-square bg-zinc-950 flex items-center justify-center">
                          <Activity className="w-6 h-6 text-emerald-500 animate-pulse" />
                        </div>
                      )}
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* DNA Sidebar */}
          <div className="space-y-6">
            <Card className="bg-zinc-900 border-zinc-800 border-l-4 border-l-emerald-500">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-bold uppercase tracking-widest flex items-center">
                    <Dna className="w-4 h-4 mr-2 text-emerald-400" />
                    Genetic Profile
                  </CardTitle>
                  <Button size="icon" variant="ghost" className="h-6 w-6 text-zinc-500 hover:text-emerald-400">
                    <RefreshCw className="w-3 h-3" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6 pt-4">
                <div className="space-y-4">
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] uppercase font-bold text-zinc-500">
                      <span>Saturation Gene</span>
                      <span className="text-emerald-400">1.2x</span>
                    </div>
                    <Progress value={80} className="h-1 bg-zinc-800" indicatorClassName="bg-emerald-500" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] uppercase font-bold text-zinc-500">
                      <span>Contrast Gene</span>
                      <span className="text-cyan-400">0.95x</span>
                    </div>
                    <Progress value={65} className="h-1 bg-zinc-800" indicatorClassName="bg-cyan-500" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] uppercase font-bold text-zinc-500">
                      <span>Motion Grain</span>
                      <span className="text-zinc-300">0.12x</span>
                    </div>
                    <Progress value={20} className="h-1 bg-zinc-800" indicatorClassName="bg-zinc-400" />
                  </div>
                </div>

                <div className="pt-4 border-t border-zinc-800">
                  <p className="text-[10px] uppercase font-bold text-zinc-500 mb-2 tracking-widest">Narrative Archetype</p>
                  <div className="bg-zinc-950 border border-zinc-800 p-3 rounded flex items-center justify-between group cursor-default">
                    <span className="text-emerald-400 font-mono tracking-tighter group-hover:text-emerald-300 transition-colors">THE MYSTERY</span>
                    <Sparkles className="w-3 h-3 text-emerald-500/50" />
                  </div>
                </div>

                <div className="bg-emerald-500/5 border border-emerald-500/10 p-4 rounded-lg space-y-2">
                   <div className="flex items-center gap-2">
                     <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                     <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest">Synthesis Engine Ready</span>
                   </div>
                   <p className="text-[10px] text-zinc-500 leading-tight font-mono">
                     CORE_VERSION: GENESIS_2.0_STABLE
                     DNA_MUTATION_RATE: 0.125
                     SYSTEM_STATUS: NOMINAL
                   </p>
                </div>
              </CardContent>
            </Card>

            <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-4 relative overflow-hidden">
               <div className="absolute top-0 right-0 p-2 opacity-5">
                 <Activity className="w-16 h-16" />
               </div>
               <p className="text-[10px] font-bold text-zinc-500 uppercase mb-4 tracking-widest">Evolution Log</p>
               <div className="space-y-3 font-mono text-[9px] text-zinc-600">
                 <p className="flex justify-between"><span>[14:20:05]</span> <span className="text-emerald-900">NEW_DNA_SPLICED</span></p>
                 <p className="flex justify-between"><span>[14:18:12]</span> <span>GEN_ID: 842_COMPLETE</span></p>
                 <p className="flex justify-between"><span>[14:15:30]</span> <span>KERN_BURNS_INIT</span></p>
                 <p className="flex justify-between"><span>[14:10:01]</span> <span className="text-cyan-900">SYSTEM_BOOTLOAD_OK</span></p>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
