import { useState, useEffect } from "react";
import { useJobs, useCreateJob, useUpload, useJob } from "@/hooks/use-jobs";
import { FileUpload } from "@/components/FileUpload";
import { JobCard } from "@/components/JobCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, Wand2, Download, RefreshCw, Zap, Image as ImageIcon, Video } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { jobTypes, type Job } from "@shared/schema";

export default function Home() {
  const [activeTab, setActiveTab] = useState<string>("speed");
  const [inputUrl, setInputUrl] = useState<string | null>(null);
  const [originalFilename, setOriginalFilename] = useState<string | null>(null);
  const [selectedJobId, setSelectedJobId] = useState<number | null>(null);

  // Form states
  const [speed, setSpeed] = useState([1.0]);
  const [duration, setDuration] = useState([5]);
  const [fps, setFps] = useState([30]);

  const { data: jobs, isLoading: isLoadingJobs } = useJobs();
  const createJob = useCreateJob();
  const upload = useUpload();
  
  // Poll selected job specifically
  const { data: selectedJob } = useJob(selectedJobId);

  // When selected job completes, update local UI if needed
  useEffect(() => {
    if (selectedJob?.status === 'completed' && selectedJobId) {
      // Optional: Sound effect or notification
    }
  }, [selectedJob?.status, selectedJobId]);

  const handleUpload = async (file: File) => {
    setOriginalFilename(file.name);
    const result = await upload.mutateAsync(file);
    setInputUrl(result.url);
  };

  const handleCreateJob = async () => {
    if (!inputUrl) return;

    let params = {};
    let type = jobTypes.SPEED;

    if (activeTab === "speed") {
      type = jobTypes.SPEED;
      params = { speed: speed[0] };
    } else if (activeTab === "anim") {
      type = jobTypes.ANIM;
      params = { duration: duration[0], fps: fps[0] };
    } else if (activeTab === "watermark") {
      type = jobTypes.WATERMARK;
      params = {};
    }

    const job = await createJob.mutateAsync({
      type,
      inputUrl,
      originalFilename: originalFilename || "file",
      params
    });

    // Reset form and select new job
    setInputUrl(null);
    setOriginalFilename(null);
    setSelectedJobId(job.id);
  };

  const clearForm = () => {
    setInputUrl(null);
    setOriginalFilename(null);
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <div className="min-h-screen bg-[url('/grid-pattern.svg')] bg-fixed bg-cover">
      <div className="absolute inset-0 bg-background/90 backdrop-blur-[100px]" />
      
      <div className="relative container mx-auto px-4 py-8 lg:py-12 max-w-7xl">
        <header className="mb-12 text-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white via-primary to-purple-400 mb-4 tracking-tight">
              Media Master AI
            </h1>
            <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto">
              Professional grade video processing tools powered by advanced AI algorithms.
            </p>
          </motion.div>
        </header>

        <div className="grid lg:grid-cols-12 gap-8">
          {/* LEFT COLUMN - WORKSPACE */}
          <div className="lg:col-span-8 space-y-8">
            <Card className="glass-panel border-0 overflow-hidden">
              <CardContent className="p-0">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <div className="bg-secondary/40 border-b border-white/5 p-2">
                    <TabsList className="grid grid-cols-3 bg-secondary/50 p-1 rounded-lg">
                      <TabsTrigger value="speed" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                        <Zap className="w-4 h-4 mr-2" /> Speed Control
                      </TabsTrigger>
                      <TabsTrigger value="anim" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                        <Video className="w-4 h-4 mr-2" /> Image to Video
                      </TabsTrigger>
                      <TabsTrigger value="watermark" className="data-[state=active]:bg-primary data-[state=active]:text-white">
                        <Wand2 className="w-4 h-4 mr-2" /> Remove Watermark
                      </TabsTrigger>
                    </TabsList>
                  </div>

                  <div className="p-6 md:p-8">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={activeTab}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        transition={{ duration: 0.3 }}
                      >
                        <TabsContent value="speed" className="mt-0 space-y-6">
                          <div className="space-y-4">
                            <div className="flex items-center justify-between">
                              <h3 className="text-xl font-semibold">Video Speed Adjustment</h3>
                              <span className="text-primary font-mono bg-primary/10 px-3 py-1 rounded-md">
                                {speed[0]}x Speed
                              </span>
                            </div>
                            
                            <div className="bg-secondary/30 p-6 rounded-xl border border-white/5">
                              <div className="flex justify-between text-xs text-muted-foreground mb-4">
                                <span>Slow Motion (0.25x)</span>
                                <span>Normal (1.0x)</span>
                                <span>Fast Forward (4.0x)</span>
                              </div>
                              <Slider
                                value={speed}
                                onValueChange={setSpeed}
                                min={0.25}
                                max={4.0}
                                step={0.25}
                                className="py-2"
                              />
                            </div>

                            <FileUpload
                              label="Drop video file to adjust speed"
                              accept={{ 'video/*': ['.mp4', '.mov', '.avi'] }}
                              onUpload={handleUpload}
                              isUploading={upload.isPending}
                              value={inputUrl}
                              onClear={clearForm}
                            />
                          </div>
                        </TabsContent>

                        <TabsContent value="anim" className="mt-0 space-y-6">
                          <div className="space-y-6">
                            <div className="grid md:grid-cols-2 gap-6">
                              <div className="space-y-3">
                                <Label>Duration: {duration[0]} seconds</Label>
                                <Slider
                                  value={duration}
                                  onValueChange={setDuration}
                                  min={1}
                                  max={15}
                                  step={1}
                                />
                              </div>
                              <div className="space-y-3">
                                <Label>Frame Rate: {fps[0]} FPS</Label>
                                <Slider
                                  value={fps}
                                  onValueChange={setFps}
                                  min={24}
                                  max={60}
                                  step={1}
                                />
                              </div>
                            </div>

                            <FileUpload
                              label="Drop image to animate"
                              accept={{ 'image/*': ['.jpg', '.png', '.jpeg', '.webp'] }}
                              onUpload={handleUpload}
                              isUploading={upload.isPending}
                              value={inputUrl}
                              onClear={clearForm}
                            />
                          </div>
                        </TabsContent>

                        <TabsContent value="watermark" className="mt-0 space-y-6">
                          <div className="space-y-4">
                            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 text-sm text-blue-200">
                              <p className="flex items-center gap-2">
                                <Wand2 className="w-4 h-4" />
                                AI will automatically detect and remove watermarks from your image.
                              </p>
                            </div>
                            
                            <FileUpload
                              label="Drop image with watermark"
                              accept={{ 'image/*': ['.jpg', '.png', '.jpeg', '.webp'] }}
                              onUpload={handleUpload}
                              isUploading={upload.isPending}
                              value={inputUrl}
                              onClear={clearForm}
                            />
                          </div>
                        </TabsContent>
                      </motion.div>
                    </AnimatePresence>

                    <div className="mt-8 pt-6 border-t border-white/5 flex justify-end">
                      <Button
                        size="lg"
                        className="w-full md:w-auto text-lg px-8 py-6 rounded-xl shadow-lg shadow-primary/20 hover:shadow-primary/40 transition-all"
                        disabled={!inputUrl || createJob.isPending}
                        onClick={handleCreateJob}
                      >
                        {createJob.isPending ? (
                          <>
                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            Start Processing
                            <Wand2 className="w-5 h-5 ml-2" />
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </Tabs>
              </CardContent>
            </Card>

            {/* PREVIEW AREA (IF JOB SELECTED) */}
            {selectedJob && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-8"
              >
                <Card className="glass-panel border-primary/20 bg-primary/5">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-xl font-semibold">Result Preview</h3>
                      <div className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
                        selectedJob.status === 'completed' ? 'bg-green-500/20 text-green-400' : 
                        selectedJob.status === 'failed' ? 'bg-red-500/20 text-red-400' : 
                        'bg-yellow-500/20 text-yellow-400'
                      }`}>
                        {selectedJob.status}
                      </div>
                    </div>

                    <div className="aspect-video bg-black/50 rounded-lg overflow-hidden flex items-center justify-center border border-white/10 relative">
                      {selectedJob.status === 'completed' && selectedJob.outputUrl ? (
                         // Render output based on job type
                         selectedJob.type === 'anim' || selectedJob.type === 'speed' ? (
                           <video 
                             src={selectedJob.outputUrl} 
                             controls 
                             className="w-full h-full object-contain"
                             autoPlay
                             loop
                           />
                         ) : (
                           <img 
                             src={selectedJob.outputUrl} 
                             alt="Result" 
                             className="w-full h-full object-contain"
                           />
                         )
                      ) : selectedJob.status === 'failed' ? (
                        <div className="text-center p-8">
                          <XCircle className="w-12 h-12 text-destructive mx-auto mb-3" />
                          <p className="text-destructive font-medium">Processing Failed</p>
                          <p className="text-sm text-muted-foreground mt-2">{selectedJob.error}</p>
                        </div>
                      ) : (
                        <div className="text-center">
                          <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto mb-3" />
                          <p className="text-primary font-medium">Processing Media...</p>
                          <p className="text-sm text-muted-foreground mt-2">This may take a moment</p>
                        </div>
                      )}
                    </div>

                    {selectedJob.status === 'completed' && selectedJob.outputUrl && (
                      <div className="mt-4 flex justify-end">
                        <Button variant="outline" className="gap-2" asChild>
                          <a href={selectedJob.outputUrl} download>
                            <Download className="w-4 h-4" /> Download Result
                          </a>
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>

          {/* RIGHT COLUMN - HISTORY */}
          <div className="lg:col-span-4">
            <Card className="h-full glass-panel border-0 flex flex-col">
              <div className="p-6 border-b border-white/5 flex items-center justify-between bg-card/50">
                <h2 className="font-semibold text-lg flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 text-primary" />
                  Recent Jobs
                </h2>
                <div className="text-xs text-muted-foreground">
                  {jobs?.length || 0} items
                </div>
              </div>
              <CardContent className="p-0 flex-1 overflow-y-auto max-h-[600px] custom-scrollbar">
                {isLoadingJobs ? (
                  <div className="p-8 flex justify-center">
                    <Loader2 className="w-8 h-8 text-primary animate-spin" />
                  </div>
                ) : jobs && jobs.length > 0 ? (
                  <div className="p-4 space-y-3">
                    {jobs.map((job) => (
                      <JobCard 
                        key={job.id} 
                        job={job} 
                        onClick={() => setSelectedJobId(job.id)}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="p-12 text-center text-muted-foreground">
                    <Wand2 className="w-12 h-12 mx-auto mb-4 opacity-20" />
                    <p>No jobs yet</p>
                    <p className="text-sm opacity-50">Create your first job to see history</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
