## Packages
framer-motion | Smooth animations for tab switching and loading states
lucide-react | Beautiful icons for the UI
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
The backend provides endpoints for file uploads at /api/upload and job creation at /api/jobs.
The frontend needs to poll for job status updates.
