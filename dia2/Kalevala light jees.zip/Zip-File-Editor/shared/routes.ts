import { z } from 'zod';
import { insertJobSchema, jobs } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  jobs: {
    create: {
      method: 'POST' as const,
      path: '/api/jobs' as const,
      input: insertJobSchema,
      responses: {
        201: z.custom<typeof jobs.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/jobs/:id' as const,
      responses: {
        200: z.custom<typeof jobs.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/jobs' as const,
      responses: {
        200: z.array(z.custom<typeof jobs.$inferSelect>()),
      },
    }
  },
  upload: {
    create: {
      method: 'POST' as const,
      path: '/api/upload' as const,
      responses: {
        200: z.object({
          url: z.string(),
          filename: z.string(),
          mimetype: z.string()
        }),
        400: errorSchemas.validation
      }
    }
  },
  ai: {
    generateImage: {
      method: 'POST' as const,
      path: '/api/ai/image' as const,
      input: z.object({
        prompt: z.string(),
        style: z.enum(['mythic', 'cyber_kalevala', 'shamanic']),
        character: z.string().optional()
      }),
      responses: {
        201: z.custom<typeof jobs.$inferSelect>(),
        400: errorSchemas.validation,
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
