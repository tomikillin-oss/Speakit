import { pgTable, text, serial, json, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'speed', 'anim', 'watermark', 'viikuoja_anim', 'viikuoja_random', 'viikuoja_story', 'ai_image'
  status: text("status").notNull().default("pending"), 
  inputUrl: text("input_url"),
  outputUrl: text("output_url"),
  originalFilename: text("original_filename"),
  error: text("error"),
  params: json("params"),
  dna: json("dna"),
  prompt: text("prompt"),
  style: text("style"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const stats = pgTable("stats", {
  id: serial("id").primaryKey(),
  framesGenerated: integer("frames_generated").default(0),
  dnaGenerations: integer("dna_generations").default(0),
  storyBranches: integer("story_branches").default(0),
  loopCycles: integer("loop_cycles").default(0),
});

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull().references(() => conversations.id, { onDelete: "cascade" }),
  role: text("role").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertJobSchema = createInsertSchema(jobs).omit({ 
  id: true, 
  status: true, 
  outputUrl: true, 
  error: true, 
  createdAt: true,
  dna: true
});

export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;

export const jobTypes = {
  SPEED: 'speed',
  ANIM: 'anim',
  WATERMARK: 'watermark',
  VIIKUOJA_ANIM: 'viikuoja_anim',
  VIIKUOJA_RANDOM: 'viikuoja_random',
  VIIKUOJA_STORY: 'viikuoja_story',
  AI_IMAGE: 'ai_image'
} as const;
